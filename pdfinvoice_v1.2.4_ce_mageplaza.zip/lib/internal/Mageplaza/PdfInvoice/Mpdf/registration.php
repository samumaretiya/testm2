<?php
$mpdf = new SplPdfInvoiceClassLoader('Mpdf', realpath(__DIR__ . DIRECTORY_SEPARATOR));
$mpdf->register();