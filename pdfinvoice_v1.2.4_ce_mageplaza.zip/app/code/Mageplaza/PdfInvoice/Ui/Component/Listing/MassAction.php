<?php
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category   Mageplaza
 * @package    Mageplaza_PdfInvoice
 * @copyright   Copyright (c) 2017-2018 Mageplaza (http://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

namespace Mageplaza\PdfInvoice\Ui\Component\Listing;

use Magento\Framework\App\RequestInterface;
use Magento\Framework\UrlInterface;
use Magento\Framework\View\Element\UiComponent\ContextInterface;
use Mageplaza\PdfInvoice\Helper\Data;
use Mageplaza\PdfInvoice\Model\Source\PrintButton;
use Mageplaza\PdfInvoice\Model\Source\Type;

/**
 * Class MassAction
 * @package Mageplaza\PdfInvoice\Ui\Component\Listing
 */
class MassAction extends \Magento\Ui\Component\MassAction
{
    /**
     * @var \Magento\Framework\UrlInterface
     */
    protected $_urlBuilder;

    /**
     * @var \Magento\Framework\App\RequestInterface
     */
    protected $_request;

    /**
     * @var \Mageplaza\PdfInvoice\Helper\Data
     */
    protected $helperConfig;

    /**
     * MassAction constructor.
     * @param \Magento\Framework\View\Element\UiComponent\ContextInterface $context
     * @param \Magento\Framework\UrlInterface $urlBuilder
     * @param \Magento\Framework\App\RequestInterface $request
     * @param \Mageplaza\PdfInvoice\Helper\Data $helperConfig
     * @param UiComponentInterface[] $components
     * @param array $data
     */
    public function __construct(
        ContextInterface $context,
        UrlInterface $urlBuilder,
        RequestInterface $request,
        Data $helperConfig,
        array $components = [],
        array $data = []
    )
    {
        $this->_urlBuilder  = $urlBuilder;
        $this->_request     = $request;
        $this->helperConfig = $helperConfig;
        parent::__construct($context, $components, $data);
    }

    /**
     * @inheritdoc
     */
    public function prepare()
    {
        parent::prepare();

        switch ($this->_request->getFullActionName()) {
            case 'sales_order_index' :

                /** With sales_order_index Magento2 did not have print PDF for order , We will replace config PrintButton::CUSTOM_PDF equal PrintButton::BOTH */
                $isShowCustomPrintForOrder = $this->helperConfig->canShowCustomPrint(Type::ORDER, 0) ? PrintButton::BOTH : false;
                $this->addMassAction($isShowCustomPrintForOrder, Type::ORDER, 'Orders', '');

                /** For: Print invoices of selected order function*/
                $this->addMassAction($this->helperConfig->canShowCustomPrint(Type::INVOICE, 0), Type::ORDER, 'Invoices', 'pdfinvoices_order', Type::INVOICE);
                break;
            case 'sales_invoice_index' :
                $this->addMassAction($this->helperConfig->canShowCustomPrint(Type::INVOICE, 0), Type::INVOICE, 'Invoices', 'pdfinvoices_order', '');
                break;
            case 'sales_shipment_index' :
                $this->addMassAction($this->helperConfig->canShowCustomPrint(Type::SHIPMENT, 0), Type::SHIPMENT, 'Shipments', 'pdfshipments_order', '');
                break;
            case 'sales_creditmemo_index' :
                $this->addMassAction($this->helperConfig->canShowCustomPrint(Type::CREDIT_MEMO, 0), Type::CREDIT_MEMO, 'Credit Memos', 'pdfcreditmemos_order', '');
                break;
        }
    }

    /**
     * Add mass action
     * @param $configPrint
     * @param $type
     * @param $label
     * @param $typeAction
     * @param string $subType
     */
    public function addMassAction($configPrint, $type, $label, $typeAction, $subType = 'none')
    {
        if ($configPrint) {
            $config = $this->getConfiguration();
            $url    = $this->_urlBuilder->getUrl('pdfinvoice/massaction/printpdf', ['type' => $type, 'subType' => $subType]);
            if ($configPrint == PrintButton::CUSTOM_PDF) {
                foreach ($config['actions'] as $key => $action) {
                    if ($action['type'] == $typeAction) {
                        $config['actions'][$key]['url'] = $url;
                        break;
                    }
                }
            } else {
                $config['actions'][] = [
                    'component' => 'uiComponent',
                    'type'      => 'mp_' . $type . '_' . $subType,
                    'label'     => __('Print PDF %1', $label),
                    'url'       => $url
                ];
            }
            $this->setData('config', (array)$config);
        }
    }
}
