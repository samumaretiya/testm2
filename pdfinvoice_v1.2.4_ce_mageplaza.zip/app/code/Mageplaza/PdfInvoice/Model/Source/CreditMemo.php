<?php
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_PdfInvoice
 * @copyright   Copyright (c) 2017-2018 Mageplaza (https://www.mageplaza.com/)
 * @license     http://mageplaza.com/LICENSE.txt
 */

namespace Mageplaza\PdfInvoice\Model\Source;

use Magento\Framework\Data\OptionSourceInterface;
use Mageplaza\PdfInvoice\Helper\Data;

/**
 * Class CreditMemo
 * @package Mageplaza\PdfInvoice\Model\Source
 */
class CreditMemo implements OptionSourceInterface
{
    /**
     * @var \Mageplaza\PdfInvoice\Helper\Data
     */
    protected $helperData;

    /**
     * CreditMemo constructor.
     * @param \Mageplaza\PdfInvoice\Helper\Data $helperData
     */
    public function __construct(Data $helperData)
    {
        $this->helperData = $helperData;
    }

    /**
     * Retrieve option array with empty value
     *
     * @return string[]
     */
    public function toOptionArray()
    {
        return $this->helperData->getTemplates(Type::CREDIT_MEMO);
    }
}
