<?php
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_PdfInvoice
 * @copyright   Copyright (c) 2017-2018 Mageplaza (https://www.mageplaza.com/)
 * @license     http://mageplaza.com/LICENSE.txt
 */

namespace Mageplaza\PdfInvoice\Model\Template;

use Magento\Framework\App\ObjectManager;
use Mageplaza\PdfInvoice\Helper\Data;
use Mageplaza\PdfInvoice\Helper\PrintProcess;
use Mageplaza\PdfInvoice\Model\Source\Type;

/**
 * Class SenderBuilder
 * @package Mageplaza\PdfInvoice\Model\Template
 */
class SenderBuilder extends \Magento\Sales\Model\Order\Email\SenderBuilder
{
    /**
     * @inheritdoc
     */
    public function send()
    {
        $this->attachPDF();
        parent::send();
    }

    /**
     * @inheritdoc
     */
    public function sendCopyTo()
    {
        $this->attachPDF();
        parent::sendCopyTo();
    }

    /**
     * Attach pdf
     */
    public function attachPDF()
    {
        $objectManager = ObjectManager::getInstance();
        $configHelper  = $objectManager->get(Data::class);

        $templateVars = $this->templateContainer->getTemplateVars();
        $store        = $templateVars['store'];
        if ($configHelper->isEnabled($store->getId())) {
            try {
                $dataHelper = $objectManager->get(PrintProcess::class);

                if (isset($templateVars['invoice'])) {
                    $invoice  = $templateVars['invoice'];
                    $content  = $dataHelper->processPDFTemplate(Type::INVOICE, $templateVars, $store->getId());
                    $fileName = 'Invoice' . $invoice->getIncrementId();
                } else if (isset($templateVars['shipment'])) {
                    $shipment = $templateVars['shipment'];
                    $content  = $dataHelper->processPDFTemplate(Type::SHIPMENT, $templateVars, $store->getId());
                    $fileName = 'Shipment' . $shipment->getIncrementId();
                } else if (isset($templateVars['creditmemo'])) {
                    $creditmemo = $templateVars['creditmemo'];
                    $content    = $dataHelper->processPDFTemplate(Type::CREDIT_MEMO, $templateVars, $store->getId());
                    $fileName   = 'Creditmemo' . $creditmemo->getIncrementId();
                } else {
                    $order    = $templateVars['order'];
                    $fileName = 'Order' . $order->getIncrementId();
                    $content  = $dataHelper->processPDFTemplate(Type::ORDER, $templateVars, $store->getId());
                }

                if ($content) {
                    $this->transportBuilder->addAttachment(
                        $content,
                        'application/pdf',
                        \Zend_Mime::DISPOSITION_ATTACHMENT,
                        \Zend_Mime::ENCODING_BASE64,
                        $fileName . '.pdf'
                    );
                }
            } catch (\Exception $e) {
                $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/pdfinvoice.log');
                $logger = new \Zend\Log\Logger();
                $logger->addWriter($writer);
                $logger->info($e->getMessage());
            }
        }
    }
}
