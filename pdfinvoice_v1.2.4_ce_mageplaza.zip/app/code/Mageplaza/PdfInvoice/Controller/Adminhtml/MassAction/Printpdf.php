<?php
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category   Mageplaza
 * @package    Mageplaza_PdfInvoice
 * @copyright   Copyright (c) 2017-2018 Mageplaza (http://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

namespace Mageplaza\PdfInvoice\Controller\Adminhtml\MassAction;

use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Framework\Controller\ResultFactory;
use Magento\Sales\Model\ResourceModel\Order\CollectionFactory as OrderCollectionFactory;
use Magento\Sales\Model\ResourceModel\Order\Creditmemo\CollectionFactory as CreditmemoCollectionFactory;
use Magento\Sales\Model\ResourceModel\Order\Invoice\CollectionFactory as InvoiceCollectionFactory;
use Magento\Sales\Model\ResourceModel\Order\Shipment\CollectionFactory as ShipmentCollectionFactory;
use Magento\Ui\Component\MassAction\Filter;
use Mageplaza\PdfInvoice\Helper\PrintProcess as HelperData;
use Mageplaza\PdfInvoice\Model\Source\Type;

/**
 * Class Printpdf
 * @package Mageplaza\PdfInvoice\Controller\Adminhtml\MassAction
 */
class Printpdf extends Action
{
    /**
     * @var string
     */
    protected $redirectUrl = 'sales/order/index';

    /**
     * @var \Magento\Ui\Component\MassAction\Filter
     */
    protected $filter;

    /**
     * @var \Mageplaza\PdfInvoice\Helper\Data
     */
    protected $helperData;

    /**
     * @var \Magento\Sales\Model\ResourceModel\Order\CollectionFactory
     */
    protected $orderCollectionFactory;

    /**
     * @var \Magento\Sales\Model\ResourceModel\Order\Invoice\CollectionFactory
     */
    protected $invoiceCollectionFactory;

    /**
     * @var \Magento\Sales\Model\ResourceModel\Order\Shipment\CollectionFactory
     */
    protected $shipmentCollectionFactory;

    /**
     * @var \Magento\Sales\Model\ResourceModel\Order\Creditmemo\CollectionFactory
     */
    protected $creditmemoCollectionFactory;

    /**
     * @var $collectionFactory
     */
    protected $collectionFactory;

    /**
     * Printpdf constructor.
     * @param \Magento\Backend\App\Action\Context $context
     * @param \Magento\Ui\Component\MassAction\Filter $filter
     * @param \Mageplaza\PdfInvoice\Helper\PrintProcess $helperData
     * @param \Magento\Sales\Model\ResourceModel\Order\CollectionFactory $orderCollectionFactory
     * @param \Magento\Sales\Model\ResourceModel\Order\Invoice\CollectionFactory $invoiceCollectionFactory
     * @param \Magento\Sales\Model\ResourceModel\Order\Shipment\CollectionFactory $shipmentCollectionFactory
     * @param \Magento\Sales\Model\ResourceModel\Order\Creditmemo\CollectionFactory $creditmemoCollectionFactory
     */
    public function __construct(
        Context $context,
        Filter $filter,
        HelperData $helperData,
        OrderCollectionFactory $orderCollectionFactory,
        InvoiceCollectionFactory $invoiceCollectionFactory,
        ShipmentCollectionFactory $shipmentCollectionFactory,
        CreditmemoCollectionFactory $creditmemoCollectionFactory
    )
    {
        parent::__construct($context);

        $this->filter                      = $filter;
        $this->helperData                  = $helperData;
        $this->orderCollectionFactory      = $orderCollectionFactory;
        $this->invoiceCollectionFactory    = $invoiceCollectionFactory;
        $this->shipmentCollectionFactory   = $shipmentCollectionFactory;
        $this->creditmemoCollectionFactory = $creditmemoCollectionFactory;
    }

    /**
     * Execute action
     *
     * @return $this|\Magento\Framework\App\ResponseInterface|\Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
        try {
            /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
            $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);

            $ids     = [];
            $storeId = '';
            $type    = $this->getRequest()->getParam('type');
            $subtype = $this->getRequest()->getParam('subType');
            $this->setTypeCollection($type);
            $collection = $this->filter->getCollection($this->collectionFactory);

            /**Print invoices of selected order*/
            if ($subtype == Type::INVOICE && $type == Type::ORDER) {
                /** For each collection data of order we must take out the ids of invoices*/
                foreach ($collection as $order) {
                    $currentStoreId = $order->getStoreId();

                    /** If order has invoice*/
                    if ($order->hasInvoices()) {
                        foreach ($order->getInvoiceCollection() as $invoice) {
                            $ids[$currentStoreId][] = $invoice->getId();
                        }
                    }
                }
                /** After get invoice's ids completed we must set type to INVOICE*/
                $type = Type::INVOICE;
            } else {
                /**Print selected orders*/
                foreach ($collection as $data) {
                    $currentStoreId = $data->getStoreId();

                    $ids[$currentStoreId][] = $data->getId();
                }
            }
            /** If $ids is null, go back*/
            if (!$ids) {
                return $resultRedirect->setPath($this->redirectUrl);
            }
            $this->helperData->printAllPdf($type, $ids, $storeId);
        } catch (\Exception $e) {
            $this->messageManager->addError($e->getMessage());

            return $resultRedirect->setPath($this->redirectUrl);
        }
    }

    /**
     * Set type collection
     * @param $type
     * @return \Magento\Sales\Model\ResourceModel\Order\Collection
     */
    public function setTypeCollection($type)
    {
        if (!$this->collectionFactory) {
            switch ($type) {
                case Type::CREDIT_MEMO :
                    $collection        = $this->creditmemoCollectionFactory;
                    $this->redirectUrl = 'sales/creditmemo/index';
                    break;
                case Type::ORDER :
                    $collection = $this->orderCollectionFactory;
                    break;
                case Type::SHIPMENT :
                    $collection        = $this->shipmentCollectionFactory;
                    $this->redirectUrl = 'sales/shipment/index';
                    break;
                default:
                    $collection        = $this->invoiceCollectionFactory;
                    $this->redirectUrl = 'sales/invoice/index';
            }

            $this->collectionFactory = $collection->create();
        }

        return $this->collectionFactory;
    }
}
