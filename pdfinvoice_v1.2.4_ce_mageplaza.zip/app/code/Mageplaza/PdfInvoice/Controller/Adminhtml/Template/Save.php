<?php
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_PdfInvoice
 * @copyright   Copyright (c) 2017-2018 Mageplaza (http://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

namespace Mageplaza\PdfInvoice\Controller\Adminhtml\Template;

use Magento\Backend\App\Action\Context;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Filesystem;
use Magento\Framework\Stdlib\DateTime\DateTime;
use Magento\Framework\View\Result\PageFactory;
use Mageplaza\PdfInvoice\Controller\Adminhtml\Template;
use Mageplaza\PdfInvoice\Helper\Data as HelperData;
use Mageplaza\PdfInvoice\Model\TemplateFactory;

/**
 * Class Save
 * @package Mageplaza\PdfInvoice\Controller\Adminhtml\Template
 */
class Save extends Template
{
    /**
     * @var \Magento\Framework\Filesystem\Directory\WriteInterface
     */
    protected $mediaDirectory;

    /**
     * @var \Magento\Framework\Stdlib\DateTime\DateTime
     */
    protected $dateTime;

    /**
     * Save constructor.
     * @param \Magento\Backend\App\Action\Context $context
     * @param \Magento\Framework\View\Result\PageFactory $resultPageFactory
     * @param \Mageplaza\PdfInvoice\Model\TemplateFactory $templateFactory
     * @param \Magento\Framework\Filesystem $filesystem
     * @param \Magento\Framework\Stdlib\DateTime\DateTime $dateTime
     * @param \Mageplaza\PdfInvoice\Helper\Data $helperData
     */
    public function __construct(
        Context $context,
        PageFactory $resultPageFactory,
        TemplateFactory $templateFactory,
        Filesystem $filesystem,
        DateTime $dateTime,
        HelperData $helperData
    )
    {
        $this->dateTime = $dateTime;
        parent::__construct($context, $resultPageFactory, $templateFactory, $helperData);
    }

    /**
     * @var \Magento\Framework\View\Result\PageFactory
     * @return void
     */
    public function execute()
    {
        $data       = $this->getRequest()->getPostValue();
        $templateId = (int)$this->getRequest()->getParam('id');
        if ($data) {
            $template = $this->_initObject();
            if (!$template->getId() && $templateId) {
                $this->messageManager->addErrorMessage(__('This template does not exist.'));
                $this->_redirect('*/*/');
            }

            if ($template->getId()) {
                $data['updated_at'] = $this->dateTime->gmtDate();
            }

            try {
                $template->addData($data)
                    ->save();

                $this->messageManager->addSuccessMessage(__('You saved the PDF template.'));
                if ($this->getRequest()->getParam('back')) {
                    $this->_redirect('*/template/edit', ['id' => $template->getId(), 'type' => $template->getType()]);

                    return;
                }
            } catch (LocalizedException $e) {
                $this->messageManager->addErrorMessage($e->getMessage());
            } catch (\Exception $e) {
                $this->messageManager->addErrorMessage($e->getMessage());
                $this->messageManager->addExceptionMessage($e, __('Something went wrong while saving template.'));
            }
        }

        $this->_redirect('*/*/');
    }
}
