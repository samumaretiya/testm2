<?php
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_PdfInvoice
 * @copyright   Copyright (c) 2017-2018 Mageplaza (http://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

namespace Mageplaza\PdfInvoice\Controller\Adminhtml\Template;

use Magento\Backend\App\Action\Context;
use Magento\Framework\Registry;
use Magento\Framework\View\Result\PageFactory;
use Mageplaza\PdfInvoice\Controller\Adminhtml\Template;
use Mageplaza\PdfInvoice\Helper\Data as HelperData;
use Mageplaza\PdfInvoice\Model\TemplateFactory;

/**
 * Class Edit
 * @package Mageplaza\PdfInvoice\Controller\Adminhtml\Template
 */
class Edit extends Template
{
    /** @var \Magento\Framework\Registry */
    protected $registry;

    /**
     * Edit constructor.
     * @param \Magento\Backend\App\Action\Context $context
     * @param \Magento\Framework\View\Result\PageFactory $resultPageFactory
     * @param \Mageplaza\PdfInvoice\Model\TemplateFactory $templateFactory
     * @param \Magento\Framework\Registry $registry
     * @param \Mageplaza\PdfInvoice\Helper\Data $helperData
     */
    public function __construct(
        Context $context,
        PageFactory $resultPageFactory,
        TemplateFactory $templateFactory,
        Registry $registry,
        HelperData $helperData
    )
    {
        $this->registry = $registry;

        parent::__construct($context, $resultPageFactory, $templateFactory, $helperData);
    }

    /**
     * @return \Magento\Backend\Model\View\Result\Page
     */
    public function execute()
    {
        $template = $this->_initObject();
        if ($template) {
            $this->registry->register('current_template', $template);

            /** @var \Magento\Backend\Model\View\Result\Page $resultPage */
            $resultPage = $this->_initAction();
            $resultPage->getConfig()->getTitle()->prepend($template->getId() ? __("Edit Template '%1'", $template->getName()) : __('Create New Template'));

            return $resultPage;
        } else {
            $this->_redirect('*/*/');
        }
    }
}
