<?php

/**
 * *
 *  Copyright © 2016 Magestore. All rights reserved.
 *  See COPYING.txt for license details.
 *
 */

namespace Magestore\OneStepCheckout\Block\Adminhtml\Widget\System\Config;
class GeoIpGuide extends \Magestore\OneStepCheckout\Block\Adminhtml\Widget\System\Config\Notification
{
    /**
     * @var string
     */
    protected $_template = 'Magestore_OneStepCheckout::system/config/guide.phtml';
}